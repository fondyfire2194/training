// Copyright (c) FIRST and other WPILib contributors.
// Open Source Software; you can modify and/or share it under the terms of
// the WPILib BSD license file in the root directory of this project.

package frc.robot.commands;

import edu.wpi.first.wpilibj.Timer;
import edu.wpi.first.wpilibj2.command.CommandBase;
import frc.robot.subsystems.HopperBelts;

public class PulseLeftBelt extends CommandBase {
  /** Creates a new PulseLeftBelt. */
  private final HopperBelts m_hopperBelts;
  private final double m_speed;
  private final double m_time;
  private double m_startTime;
  private boolean m_direction;

  public PulseLeftBelt(HopperBelts hopperBelts, double speed, double time) {
    // Use addRequirements() here to declare subsystem dependencies.
    m_hopperBelts = hopperBelts;
    m_speed = speed;
    m_time = time;
  }

  // Called when the command is initially scheduled.
  @Override
  public void initialize() {
    m_startTime = Timer.getFPGATimestamp();
    m_direction = false;
  }

  // Called every time the scheduler runs while the command is scheduled.
  @Override
  public void execute() {
    if (m_direction)
      m_hopperBelts.runLeftBelt(m_speed);
    else
      m_hopperBelts.runLeftBelt(-m_speed);

    if (!m_direction && Timer.getFPGATimestamp() > m_startTime + m_time) {
      m_direction = true;
      m_startTime = Timer.getFPGATimestamp();
    }
  }

  // Called once the command ends or is interrupted.
  @Override
  public void end(boolean interrupted) {
    m_hopperBelts.runLeftBelt(0);
  }

  // Returns true when the command should end.
  @Override
  public boolean isFinished() {
    return m_direction && Timer.getFPGATimestamp() > m_startTime + m_time;
  }
}
