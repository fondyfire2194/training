// Copyright (c) FIRST and other WPILib contributors.
// Open Source Software; you can modify and/or share it under the terms of
// the WPILib BSD license file in the root directory of this project.

package frc.robot.subsystems;

import edu.wpi.first.wpilibj.Spark;
import edu.wpi.first.wpilibj2.command.SubsystemBase;

public class HopperBelts extends SubsystemBase {

  // The Romi has the left and right motors set to
  // PWM channels 0 and 1 respectively
  private final Spark m_leftBeltMotor = new Spark(0);
  private final Spark m_rightBeltMotor = new Spark(1);

  /** Creates a new HopperBelts. */
  public HopperBelts() {
    m_leftBeltMotor.set(0);
    m_rightBeltMotor.set(0);

  }

  public void runLeftBelt(double speed) {
    m_leftBeltMotor.set(speed);
  }

  @Override
  public void periodic() {
    // This method will be called once per scheduler run
  }
}
